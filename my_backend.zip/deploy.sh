#!/bin/bash

set -e

# 1. 打包当前目录为 zip（忽略 .next 和 node_modules）
echo "📦 打包中..."
rm -f my_backend.zip
mkdir -p tmp_my_backend
rsync -av --progress ./ ./tmp_my_backend --exclude node_modules --exclude .next --exclude tmp_my_backend --exclude my_backend.zip
cd tmp_my_backend
zip -r ../my_backend.zip . > /dev/null
cd ..
rm -rf tmp_my_backend

# 2. 上传 zip 到远程
echo "🚀 上传到远程服务器..."
sshpass -p "Jinzhi@123" scp my_backend.zip root@8.130.69.116:~/code/