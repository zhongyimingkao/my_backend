const params = [
    {
      locale: 'zh',
      auth: 'login'
    },
    {
      locale: 'en',
      auth: 'login'
    },
    {
      locale: 'zh',
      auth: 'register'
    },
    {
      locale: 'en',
      auth: 'register'
    }
  ]

export default params